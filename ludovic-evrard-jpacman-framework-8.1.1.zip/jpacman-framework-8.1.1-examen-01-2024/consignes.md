
# INFOM124 Vérification et validation logicielle : Examen (janvier 2024)

- Nom : *Evrard*
- Prénom : *Ludovic*

## Consignes générales

- La durée maximale de l’examen est de **4 heures**.
- L'examen est à cours ouvert.
- L'examen est individuel, la communication avec autrui est interdite. En particulier l'utilisation de messagerie instantanée, de mails ou de tout autre système de partage d'information avec d'autres étudiant.e.s passant l'examen seront considérés comme une tricherie.
- Les réponses (aussi appelés rapports) doivent être indiquées dans les espaces prévus à cet effet dans le présent document, ainsi qu'éventuellement dans le code source remis au début de l'examen.

## Méthode de cotation

Le but de l'examen est de démontrer votre capacité à analyser la qualité globale d'une codebase aux moyens des outils et techniques vues en cours.

Pour vous aider à adopter une approche structurée, 9 "pistes guidées" vous sont fournies plus loin dans ce document. Ces pistes, comme leur nom l'indique, ont pour but de vous orienter vers des zones de la codebase dans lesquels des problèmes sont assurément présents. Elles sont également divisées en sous-questions vous ayant pour bu de vous aider à structurer votre manière de rapporter les soucis de qualité en question.

**Il n'est pas nécessaire de répondre à toutes les sous-questions afin d'engranger des points pour cette question.** Au plus vous allez loin, au plus la piste vous rapportera de points. Très concrètement, le rapport que vous faites sous chaque piste guidée sera évalué comme suit :

* *Insuffisant* : le rapport est vide ou totalement erroné (0 points).
* *Insuffisfaisant* : le rapport est parcellaire ou "à côté de la plaque", mais comporte des éléments factuels **et** originaux(*) (0.25 point).
* *Satisfaisant* : le diagnostic et la correction proposés dans le rapport sont corrects et étayés (0.5 point).
* *Bon* : le diagnostic, la correction et l'action préventive proposés dans le rapport sont corrects et étayés (0.75 point).
* *Très bon* : le diagnostic, la correction et l'action préventive proposés dans le rapport sont corrects et étayés et la correction a été appliquées dans le code source (1 point).

(*) Par "originaux", on entend un élément ayant fait l'objet d'une réflexion et/ou interprétation par l'étudiant ; recopier textuellement un morceau du rapport de SonarQube, Checkstyle ou autre ne vous accordera pas de points.

Les 9 pistes guidées sont réparties en 3 catégories liées au type de problème abordé (code smells, defects, bad development practices). Le seuil minimum de réussite (10/20) est atteint si vous répondez de manière satisfaisante à 5 questions, **avec au moins 1 question par catégorie**.

Votre score final sera alors :

* 4/20 (si vous avez répondu de manière satisfaisante à une seule catégorie).
* 7/20 (si vous avez répondu de manière satisfaisante à deux catégories)
* 10 + X(**) (si vous avez répondu de manière satisfaisante à trois catégories)

(**) X étant une "marge de réussite" comprise entre 0 et 10 et calculée sur base de la qualité des réponses fournies aux différentes pistes.

Veuillez noter qu'une 10e piste (*Analyse complémentaire*) est ouverte et vous demande de faire une analyse globale de la qualité du projet sur base des différents rapports d'analyse qui vous sont fournis. Celle-ci compte dans la marge de réussite ci-dessus.

## Projet à analyser

Le projet à tester est un jeu de Pacman où le joueur contrôle un personnage appelé Pac-Man, dont l'objectif est de manger toutes les pac-gommes présentes dans un labyrinthe tout en évitant d'être touché par les fantômes. Le jeu se déroule dans un labyrinthe composé de passages et de murs. Il y a également des pac-gommes dispersées dans le labyrinthe, ainsi que des bonus comme les fruits qui apparaissent à intervalles réguliers.

Pac-Man peut se déplacer vers le haut, le bas, la gauche et la droite à travers les passages du labyrinthe. Le but principal de Pac-Man est de manger toutes les pac-gommes présentes dans le labyrinthe. Chaque fois qu'il mange une pac-gomme, le score du joueur augmente.

Il y a plusieurs fantômes dans le jeu, chacun ayant son propre comportement. Les fantômes poursuivent Pac-Man dans le labyrinthe et tentent de le capturer. Si Pac-Man est touché par un fantôme, il perd une vie. En plus des pac-gommes normales, il y a des super pac-gommes spéciales. Lorsque Pac-Man mange une super pac-gomme, les fantômes deviennent vulnérables pendant un court laps de temps. Pendant cette période, Pac-Man peut les manger pour obtenir des points supplémentaires. Le jeu se termine lorsque toutes les pac-gommes ont été mangées ou lorsque le joueur perd toutes ses vies.

### Structure du projet

Le projet utilise Maven. Pour rappel, la structure d'un projet Maven est la suivante :
- `src/main/java` contient le code source de l'application.
- `src/test/java` contient les tests de l'application.
- `target/` contient les résultats du *build* (code compilé, résultats des tests, rapports d'analyse, etc.).

La classe `nl.tudelft.jpacman.Launcher` est la classe principale qui gère le lancement d'une partie.

### Configuration du build

La commande suivante permet de lancer le *build* du projet, à savoir la compilation et l'exécution des tests :
```
mvn clean package
``` 
Si Maven n'est pas installé sur votre machine, vous pouvez également exécuter depuis la racine du projet (sur Linux et MacOS) :
```
./mvnw clean package
``` 
Ou sur Windows :
```
mvnw.cmd clean package
``` 

La configuration du build inclus déjà toute une série d'outils d'analyse :
- Checkstyle, un outil d'analyse statique permettant de vérifier que les conventions d'écriture de code sont respectées. L'outil offre une configuration par défaut qui peut être adaptée et customisée selon les besoins.
- PMD, un outil d'analyse statique permettant de repérer les erreurs de programmation courantes.
- SpotBugs, un outil d'analyse statique permettant de repérer des bugs.
- JaCoCo, un outil d'analyse dynamique fournissant des indications sur la couverture structurelle des tests.
- PIT, un outil d'analyse dynamique permettant d'effectuer une analyse de mutation.

**Note :** L'archive .zip qui vous a été remise contient déjà une copie des différents rapports pour la version du projet dans le dossier `rapports/`. **Ces rapports sont suffisants pour répondre à la plus grande partie des pistes ci-après.** Si vous voulez aller plus loin, il est également possible de re-générer ces rapports via la commande suivante (ou `./mvnw` ou `mvnw.cmd`) :
```
./mvnw clean test org.pitest:pitest-maven:mutationCoverage site
``` 
Une fois la commande exécutée, les rapports générés sont disponibles dans `target/site/index.html` (sous le menu à gauche *Project Reports*).

****************************************************************************************

## Pistes guidées - Mauvaises pratiques de développement

### Classe ScorePanel

La classe `nl.tudelft.jpacman.ui.ScorePanel` présente un anti-pattern ou ne respecte pas une convention de codage. Essayez de résoudre le problème.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Comment pourriez-vous vous y prendre pour identifier le problème spécifique à cette classe de manière systématique ?*
- Pair review du code source avec analyse statique du code


#### Diagnostic
*Indiquez ci-dessous le problème identifié et les impacts qu'il pourrait avoir.*
- Commented-Out Code: Code mort présent dans le code source


#### Action(s) corrective(s)
*Indiquez ci-dessous la ou les actions(s) correctives(s) pour corriger le problème et s'assurer que ce problème en particulier ne se représente plus.*
- Retirer l'ensemble des commentaires, on peut les retrouver avec les outils de versionning en cas de besoin.


#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe.*
- Ne pas laisser de code mort dans le code source... (commentaires, code inutile, etc.)
- Commenter le temps de la refactorisation et modification du code, tester, une fois que tout fonctionne supprimer le code en question et faire un comit. En cas de besoin, il reste accessible depuis les outils de versionning.


### Classe Navigation

La classe `nl.tudelft.jpacman.npc.ghost.Navigation` présente un anti-pattern ou ne respecte pas une convention de codage. Essayez de résoudre le problème.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Comment pourriez-vous vous y prendre pour identifier le problème spécifique à cette classe de manière systématique ?*
- Pair review du code source avec analyse statique du code
- SonarQube
- Checkstyle


#### Diagnostic
*Indiquez ci-dessous le problème identifié et les impacts qu'il pourrait avoir.*
- Nom de varibale non explicite `shortestPath(Square a, Square b, Unit c)` à savoir à quel élément correspond `a`, `b` et `c` et pour les autres méthodes aussi ?
- Il n'y a pas de JavaDoc pour expliquer le fonctionnement de la méthode avec les variables, les paramètres et les retours (surement retiré pour l'examen :-) ).
- La méthode `shortestPath` devrait retourner une liste vide plutôt qu'un null
- Inversion de `this.z = y;` et `this.y = z;`
- getParent() est une méthode qui n'est pas utilisée

#### Action(s) corrective(s)
*Indiquez ci-dessous la ou les actions(s) correctives(s) pour corriger le problème et s'assurer que ce problème en particulier ne se représente plus.*
- sélection de chaque variable et utilisation de la commande shift + f6 (et ne pas être radin en nombre de lettre!)
- utilisation de chat GPT pour renommer les variables/méthodes et rendre le code plus lisible.


#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe.*
- Toujours donner des noms de variables et fonctions explicites


### Classe CollisionMap - finish

La classe `nl.tudelft.jpacman.level.CollisionMap` présente un anti-pattern ou ne respecte pas une convention de codage. Essayez de résoudre le problème.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Comment pourriez-vous vous y prendre pour identifier le problème spécifique à cette classe de manière systématique ?*
- Pair review du code source avec analyse statique du code


#### Diagnostic
*Indiquez ci-dessous le problème identifié et les impacts qu'il pourrait avoir.*
- L'interface CollisionMap utilise le néerlandais pour les commentaires et noms de variables... Toujours utilise l'anglais pour être accessble au plus grand nombre de développeur dans le monde.


#### Action(s) corrective(s)
*Indiquez ci-dessous la ou les actions(s) correctives(s) pour corriger le problème et s'assurer que ce problème en particulier ne se représente plus.*
- Traduire du néerlandais vers l'anglais (merci google translate)


#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe.*
- English Only: les commentaires, noms de variables/méthodes, etc. Doivent être rédigée en anglais pour être compris par un maximum de développeur.

****************************************************************************************

## Pistes guidées - Code smells

### Packages ghost, level et sprite

Votre collègue Jean-Michel Àpeuprès vous fait remarquer que lorsqu'il implémente une fonctionnalité, il doit souvent modifier les packages `nl.tudelft.jpacman.npc.ghost`, `nl.tudelft.jpacman.level` et `nl.tudelft.jpacman.sprite` en même temps. Vous n'avez pas tout compris de ce qu'il marmonnait dans sa barbe, mais il semblerait qu'il y ait quelque chose à propos de couleurs. Quel est selon vous le problème ?

#### Technique(s) utilisée(s) pour poser le diagnostic
*Comment pourriez-vous vous y prendre pour trouver ce(s) code smell(s) de manière systématique ?*
- Pair review du code source avec analyse statique du code


#### Diagnostic
*Indiquez ci-dessous le(s) code smell(s) identifié(s).*
- Shotgun surgery. Si on modifie une classe, on doit modifier les autres classes qui sont liées. Il faut donc refactoriser le code pour éviter cela.
- La gestion des couleurs est gérée dans Ghost factory, on pourrai lister les différents couleurs via un Enum/hashmap et laisser la class Gost gérer la couleur en fonction du type concret (avec le polymofphisme)
- L'utilisation d'injection de dépendance avec l'utilisation de classe comme contrat pourrai être une bonne piste à explorer


#### Action(s) corrective(s)
*Indiquez ci-dessous la ou les actions(s) correctives(s) pour corriger le problème et s'assurer que ce(s) code smell(s) en particulier ne se représente plus.*
- Supprimer les constantes utilisées à usage unique et utiliser un hashmap, liste ou autre...
- Idéalement avoir la gestion de la couleur qui se base sur le type concret de la classe (polymorphisme).

#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe.*
- Penser KISS: clairement un fantome de couleur différent qui est une sous class est overkill ce seul détail si petit. Même si on a besoin d'autre attribut pour les classes filles cette information peut être remontée à la classa parente.
- Utiliser une injection de dépendance pour éviter les dépendances fortes entre les classes.
- Penser au classe métier et classe technique pour éviter les dépendances fortes entre les classes.

### Classe Level

La classe `Level` du package `nl.tudelft.jpacman.level` contient un certain nombre de méthodes qu'il vous faut reviewer avant d'effectuer un pull request sur le repo du projet. Le code s'exécute correctement, mais Jean-Michel Àpeuprès, qui a implémenté cette classe, vous dit que lorsqu'il veut modifier une méthode, il doit parfois en modifier une autre. Quelles sont ces méthodes ? Quel est le problème et comment pouvez-vous le résoudre ?

#### Technique(s) utilisée(s) pour poser le diagnostic
*Comment pourriez-vous vous y prendre pour trouver ce(s) code smell(s) de manière systématique ?*
- Pair review


#### Diagnostic
*Indiquez ci-dessous le(s) code smell(s) identifié(s).*
- Le commentaire de Jean-Michel Àpeuprès indique un couplage fort entre différentes méthodes, il serait bon d'extraire certaines méthodes pour éviter cela si cela est problématique. 
- De plus il y a du code dupliqué !

#### Action(s) corrective(s)
*Indiquez ci-dessous la ou les actions(s) correctives(s) pour corriger le problème et s'assurer que ce(s) code smell(s) en particulier ne se représente plus.*
- Extraction du code dupliqué dans la méthode `updateObservers()`


#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe.*
- Think!: Si on fait un copier/coller se dire qu'on ne fait pas les choses correctement... Extraire dans une méthode permet de faciliter la maintenance en corrigeant éventuellement le code à un et un seul endroit.

### Classe MapParser

Jean-Michel Àpeuprès a implémenté la classe `MapParser`, du package `nl.tudelft.jpacman.level`. Plusieurs développeurs ont regardé son code et pointent un problème dans cette classe, et plus particulièrement dans la méthode `parseMap(char[][] map)`. Quel est ce problème ?
! c'est `makeGrid(char[][] map, int width, int height, Square[][] grid, List<Ghost> ghosts, List<Square> startPositions)` qui pose problème

#### Technique(s) utilisée(s) pour poser le diagnostic
*Comment pourriez-vous vous y prendre pour trouver ce(s) code smell(s) de manière systématique ?*
- Pair review du code source avec analyse statique du code
- Checkstyle


#### Diagnostic
*Indiquez ci-dessous le(s) code smell(s) identifié(s).*
- Switch Statements: La méthode `makeGrid(char[][] map, int width, int height, ...)`, contient deux boucles imbrimquées avec un switch case fort long
- Certaine méthode Manque de JavaDoc pour expliquer le fonctionnement
- Méthode trop long (discutable)...


#### Action(s) corrective(s)
*Indiquez ci-dessous la ou les actions(s) correctives(s) pour corriger le problème et s'assurer que ce(s) code smell(s) en particulier ne se représente plus.*
- Extraire la méthode dans le for pour la mettre dans une méthode `addSquare()` à part
- Extraire la fonction de création de la case fantome dans une méthode `addGostSquare()` à part


#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe.*
- Si on a besoin d'écrire un commentaire pour expliquer ce qu'on fait en plein milieu de notre méthode... Il est surement probable que ça soit une bonne idée d'extraire cette partie dans sa propre méthode.
- Toujours ajouter les commentaires JavaDoc pour aider à l'utilisation des méthodes avec l'autocompression de l'IDE

****************************************************************************************

## Pistes guidées - Defects

### Méthode BoardFactory.createBoard

Depuis la dernière mise à jour, un nombre croissant de rapports de bugs semblent pointer la méthode `nl.tudelft.jpacman.board.BoardFactory.createBoard`, dont la suite de tests dans la classe `BoardFactoryTest` ne semble pas très fournie. Essayez de résoudre le problème. 

#### Technique(s) utilisée(s) pour poser le diagnostic
*Comment pourriez-vous vous y prendre pour trouver ce defect de manière systématique ?*
- Écrire les tests sur base des requirements indiqués dans la méthode 
  - les différentes cellules doivent être connectées via les directions suivantes : NORTH, SOUTH, EAST, WEST


#### Diagnostic
*Indiquez ci-dessous le defect identifié, ainsi que le ou les tests permettant de le confirmer. Donnez au minimum : les valeurs d'entrées à utiliser pour le ou les tests, le résultat normalement attendu et la manière dont le defect se manifeste (la failure observable). Alternativement, modifiez le code du projet pour ajouter un ou plusieurs tests JUnit et indiquez-le ci-dessous, nous exécuterons alors les tests directement.*
- Les tests `BoardFactoryTest` ne réussissent pas... 
  - `java.lang.ArrayIndexOutOfBoundsException: Index 1 out of bounds for length 1`
  - ``
- Après analyse du code il semble avoir un souci avec `Square neighbour = grid[dirY][dirY];` qui utilise `dirY` deux fois...


#### Action(s) corrective(s)
*Indiquez ci-dessous la ou les actions(s) correctives(s) pour corriger le problème et s'assurer que ce(s) defect(s) en particulier ne se représente plus.*
- Remplacer `Square neighbour = grid[dirY][dirY];` par `Square neighbour = grid[dirX][dirY];`, le test `BoardFactoryTest` est maintenant fonctionnelle


#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe.*
- Écrire les tests pour les aspects importants de la fonction... Ici on devait juste vérifier la connexion nord, sud, est, ouest cela ne représente pas un gros travail...

### Méthode Level.registerPlayer

Jean-Michel Àpeuprès a récemment implémenté la méthode `nl.tudelft.jpacman.level.Level.registerPlayer` (et les tests correspondants dans la classe `LevelTest`) mais celle-ci semble ne pas fonctionner dans tous les cas. Essayez de résoudre le problème.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Comment pourriez-vous vous y prendre pour trouver ce defect de manière systématique ?*
- Écrire les tests sur base des requirements indiqués dans la méthode

#### Diagnostic
*Indiquez ci-dessous le defect identifié, ainsi que le ou les tests permettant de le confirmer. Donnez au minimum : les valeurs d'entrées à utiliser pour le ou les tests, le résultat normalement attendu et la manière dont le defect se manifeste (la failure observable). Alternativement, modifiez le code du projet pour ajouter le test JUnit et indiquez-le ci-dessous, nous exécuterons alors le test directement.*
- La méthode `registerPlayer(Player player)` indique `player can only be registered once` aucun test ne vérifie cela, et il n'y a pas de condition dans la méthode qui le vérifie aussi...
- L'écriture du test `LevelTest.registerPlayerTwice()` permet de mettre en évidence le problème


#### Action(s) corrective(s)
*Indiquez ci-dessous la ou les actions(s) correctives(s) pour corriger le problème et s'assurer que ce(s) defect(s) en particulier ne se représente plus.*
- Ajouter une condition pour vérifier que le joueur passé en paramètre n'est pas déjà présent dans la variable `players`
- L'utilisation de mutant peut aussi être intéressant dans les parties critiques du code...

#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe.*
- Lister les jeux de tests indispensables en fonction de requirement indiqué (player can only be registered once, registering a player again will have no effect.), ce qui donne au niveau de tests:
  - Joueur null
  - Un joueur
  - Deux fois le même joueur
  - Deux joueurs différents
  - Case vide

### Méthode Unit.occupy

Depuis sa dernière mise-à-jour la méthode `nl.tudelft.jpacman.board.Unit.occupy` pose quelques soucis. Pourtant, les tests correspondants de la classe `OccupantTest` passent tous. Essayez de résoudre le problème.

#### Technique(s) utilisée(s) pour poser le diagnostic
*Comment pourriez-vous vous y prendre pour trouver ce defect de manière systématique ?*
- Écriture des tests sur base des requirements indiqués dans la méthode
- Tester le programme directement. 


#### Diagnostic
*Indiquez ci-dessous le defect identifié, ainsi que le ou les tests permettant de le confirmer. Donnez au minimum : les valeurs d'entrées à utiliser pour le ou les tests, le résultat normalement attendu et la manière dont le defect se manifeste (la failure observable). Alternativement, modifiez le code du projet pour ajouter le test JUnit et indiquez-le ci-dessous, nous exécuterons alors le test directement.*
- Le macman ainsi que les fantomes se multiplie... Il y a surement un objet à retirer quelque part.


#### Action(s) corrective(s)
*Indiquez ci-dessous la ou les actions(s) correctives(s) pour corriger le problème et s'assurer que ce(s) defect(s) en particulier ne se représente plus.*
- Si le carré actuel n'est pas vide, on retire l'occupant de la case avant de l'ajouter la nouvelle position.


#### Pratique(s) de développement à modifier
*Indiquez ci-dessous la ou les pratiques de développement à mettre en place pour empêcher qu'un problème similaire ne survienne à nouveau à l'avenir dans cette classe ou dans une autre classe.*
- Identifier les cas d'utilisation légitime et ceux qui pourraient poser problème pour écrire quelques jeux de tests qui permettent de vérifier le bon comportement.


****************************************************************************************

## Analyse complémentaire

*Cette dernière question est ouverte et vous demande de faire une analyse globale de la qualité du projet sur base des différents rapports d'analyse qui vous sont fournis. Vous pouvez également indiquer des recommandations à mettre en place (pratiques de développement à modifier) afin d'améliorer et de maintenir le niveau de qualité du projet.*

### Retour

Globalement, la qualité du code de notre projet est satisfaisante, mais il y a des opportunités d'amélioration qui auraient pu être détectées plus tôt par l'équipe en utilisant les outils et rapports disponibles.

L'analyse effectuée avec SonarQube a révélé la présence de 59 codes smells (réduit à 54). Bien que tous ne soient pas nécessairement critiques, ce nombre suggère la possibilité d'améliorations dans la structure et la lisibilité du code. Désactiver les règles de code smells qui ne sont pas pertinentes pour le projet pourrait aider à réduire le nombre de faux positifs et à se concentrer sur les problèmes les plus importants.  Une révision attentive de ces avertissements pourrait contribuer à renforcer la qualité globale du code.

La couverture de test actuelle est vraiment basse, seulement 15,4% (augmenté à 16.1%). Il serait bénéfique de viser une couverture minimale de 60%, en particulier pour les fonctions critiques du système. Une augmentation significative de la couverture de test contribuera à assurer une meilleure robustesse du code et à identifier d'éventuels défauts plus tôt dans le processus de développement. Plusieurs erreurs auraient pu être évitées avec quelques tests basés sur les requirements indiqués en commentaire.

Pour maintenir une cohérence dans le style du code, il est recommandé d'utiliser un outil de mise en forme automatique tel que Prettier. Cela aidera à éviter les problèmes liés aux conventions de codage et garantira une apparence uniforme du code au sein de l'équipe.

L'utilisation d'un outil de mutation testing peut être bénéfique pour vérifier la qualité des tests existants. Cela garantirait que les tests sont bien écrits, pertinents et qu'ils couvrent efficacement le code source. Un bon exemple d'outil serait PIT, qui peut identifier les faiblesses des suites de tests.

Une approche agile, intégrant la correction continue de code, le refactoring régulier et des sessions de pair programming, peut grandement améliorer la qualité du code. Ces pratiques, bien qu'elles dépendent de la taille de l'équipe, du temps disponible et du budget, peuvent considérablement contribuer à la maintenance d'un code sain et à la prévention des problèmes potentiels.

En conclusion, en mettant en œuvre ces recommandations, l'équipe peut travailler de manière plus efficace pour garantir une qualité de code optimale, tout en tenant compte des contraintes spécifiques telles que la taille de l'équipe, le temps et le budget disponibles.

Je vous félicite déjà pour le travail accompli jusqu'à maintenant et j'espère que ces quelques recommandations seront utiles.
