package nl.tudelft.jpacman.level;

import nl.tudelft.jpacman.board.Unit;

/**
 * A table with all (relevant) collisions between different types
 * units.
 *
 * @author Jeroen Roosen
 */
public interface CollisionMap {

    /**
     * Allows the two units to collide and handles the outcome of the collision, which is possible
     * be nothing at all.
     *
     * @param <C1> The collision type.
     * @param <C2> The colliding type (unit moved into).
     * @param collider The unit that causes the collision by occupying a space
     * there is already another device on it.
     * @param collides The unit already on the space being invaded.
     */
    <C1 extends Unit, C2 extends Unit> void collide(C1 collider, C2 collides);

}
