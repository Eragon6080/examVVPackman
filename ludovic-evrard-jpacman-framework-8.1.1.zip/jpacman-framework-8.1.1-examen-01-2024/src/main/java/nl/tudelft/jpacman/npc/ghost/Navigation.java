package nl.tudelft.jpacman.npc.ghost;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import nl.tudelft.jpacman.board.Direction;
import nl.tudelft.jpacman.board.Square;
import nl.tudelft.jpacman.board.Unit;

public final class Navigation {

    private Navigation() {
    }

    public static List<Direction> shortestPath(Square from, Square to,
                                               Unit unit) {
        if (from.equals(to)) {
            return new ArrayList<>();
        }

        List<Node> targets = new ArrayList<>();
        Set<Square> availables = new HashSet<>();
        targets.add(new Node(null, from, null));
        while (!targets.isEmpty()) {
            Node next = targets.remove(0);
            Square available = next.getSquare();
            if (available.equals(to)) {
                return next.getPath();
            }
            availables.add(available);
            addNewTarget(unit, available, availables, targets, next);
        }
        return new ArrayList<>();
    }

    private static void addNewTarget(Unit unit, Square available, Set<Square> availables, List<Node> targets, Node next) {
        for (Direction direction : Direction.values()) {
            Square nextSquare = available.getSquareAt(direction);
            if (!availables.contains(nextSquare)
                    && (unit == null || nextSquare.isAccessibleTo(unit))) {
                targets.add(new Node(direction, nextSquare, next));
            }
        }
    }

    public static Unit findNearest(Class<? extends Unit> unitType,
                                   Square initialSquare) {
        List<Square> queue = new ArrayList<>();
        Set<Square> visited = new HashSet<>();

        queue.add(initialSquare);

        while (!queue.isEmpty()) {
            Square currentSquare = queue.remove(0);

            // Recherche d'unités dans la case actuelle
            Unit foundUnit = null;
            for (Unit occupant : currentSquare.getOccupants()) {
                if (unitType.isInstance(occupant)) {
                    assert occupant.hasSquare();
                    foundUnit = occupant;
                }
            }

            if (foundUnit != null) {
                assert foundUnit.hasSquare();
                return foundUnit;
            }

            visited.add(currentSquare);

            for (Direction direction : Direction.values()) {
                Square neighborSquare = currentSquare.getSquareAt(direction);
                if (!visited.contains(neighborSquare) && !queue.contains(neighborSquare)) {
                    queue.add(neighborSquare);
                }
            }
        }
        return null;
    }

    private static final class Node {


        private final Direction direction;

        private final Node parent;

        private final Square square;

        /**
         * Creates a new node.
         *
         * @param direction
         * @param square
         * @param parent
         */
        Node(Direction direction, Square square, Node parent) {
            this.direction = direction;
            this.square = square;
            this.parent = parent;
        }

        /**
         * @return The direction for this node, or <code>null</code> if this
         * node is a root node.
         */
        private Direction getDirection() {
            return direction;
        }

        /**
         * @return The square for this node.
         */
        private Square getSquare() {
            return square;
        }

        /**
         * @return The parent node, or <code>null</code> if this node is a root
         * node.
         */
        private Node getParent() {
            return parent;
        }

        /**
         * Returns the list of values from the root of the tree to this node.
         *
         * @return The list of values from the root of the tree to this node.
         */
        private List<Direction> getPath() {
            if (parent == null) {
                return new ArrayList<>();
            }
            List<Direction> path = parent.getPath();
            path.add(getDirection());
            return path;
        }
    }
}
